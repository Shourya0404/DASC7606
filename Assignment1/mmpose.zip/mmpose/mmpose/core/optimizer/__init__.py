# Copyright (c) OpenMMLab. All rights reserved.
from .builder import OPTIMIZERS, build_optimizers

__all__ = ['build_optimizers', 'OPTIMIZERS']
